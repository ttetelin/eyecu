/*
 ********* WRITE MODE ********
 * Start
 * Slave Address (MSB 7bit)	
 * 0
 * <Acknowledge>
 * Sub Address (8 bit)
 * <Acknowledge>
 * Data 1 (8 bit)
 * <Acknowledge>
 * Data n (8 bit)
 * <Acknowledge>
 * Stop
 * 
 ******** READ MODE ********
 * Start
 * Slave Address (MSB 7 bit)
 * 0
 * <Acknowledge>
 * Sub Address (8 bit)
 * <Acknowledge>
 * Start
 * Slave Address (MSB 7 bit)
 * 1
 * <Data 1 (8 bit)>
 * Acknowledge
 * <Data n (8 bit)>
 * Acknowledge
 * Stop
 */
 ///////////////////////////////////////NOTES/////////////
 // SLAVE ADDRESS 0x78
 // Camera Address 0x3c
  // Suggested camera command initialization order (by hex register address): 02,1e,03
 // RapidFire order - 02,03,04,1E,03
 ////////////////////////////////////////////////////////
 
 /*	Frame rate, frequency, DCLK polarity */
 //Address 02h	11XX XX00 - 0x30
 // Frame Rate			(0 = 30fps, 	1 = 15fps) 			B7
 // AC Freq	(flckr)		(0 = 50Hz,		1 = 60Hz)			B6
 // Polarity of DCLK	(0 = norm,  	1 = inverted)		B1
 // Auto flckr det		(0 = on,		1 = off)			B0
 
 /* Enable data outputs, set camera resolution to SUBQCIF full for testing, data output to format YUV422, and image color */
 //Address 03h	0010 0000 - 0x20
 // DOUTSW	dout,hd,vd	(0 = enable,	1 = disable)		B7
 // DATAHZ	dout,hd,vd	(0 = enable,	1 = disable HI-Z)	B6
 // PICSZ 	SUBQCIF full 128x96 - decimal 8, b1000 			B5-2 
 // PICFMT				(0 = YUV422,	1 = RGB565)			B1
 // CM					(0 = color,		1 = B/W)			B0
 
 /* Set image inversion preferences and exposure length/time */
 //Address 04h	1100 0000 - C0
 // V_INV vert flip		(0 = normal,	1 = vertical flip)	B7	
 // H_INV horizontal flp(0 = normal,	1 = hrzntl flip)	B6	
 // ESRLSW (fps expose)  0 = normal 15||30fps				B5-4
 //						 1 = long 3.75fps
 //					   2,3 = Extra long
 // V_LENGTH (only for ESRLSW 2-3)							B3-0
 //					   0,1 = 1 frame interval
 //					   2-F = 2-15 frame intervals
 
 //Address 05h	
 // ALCSW luminance crl (0 = ALC ON, 	1 = ALC OFF)		B7
 // ESRLIM max exp tim 0-3									B6-5	?? 0

 /*	Testing for Color bar, Enable Synchronizations*/
 //Address 1eh	0110 1100 - 6C 						
 // D_MASK													B7-6	
 // CODESW data out syn	(0 = w/o synch,	1 = w/ synch)		B5
 // CODESEL slct syn	(0 = FS FE etc,	1 = ITU656)			B4
 // HSYNCHSEL h syn		(0 = normal,	1 = blanking)		B3
 // TESTPIC	output test	(0 = test OFF,	1 = test ON)		B2
 // PICSEL test pattern										B1-0
 //						0 = color bar
 //						1 = ramp wave after gamma
 //						2 = ramp wave before gamma
 //						3 = normal picture
 
